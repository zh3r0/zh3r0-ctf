you can find mujs release version in ./build/ dir, jsUint16Array.c, jsUint32Array.c, jsUint8Array.c, jsarraybuffer.c is added, do git diff HEAD to find patches
